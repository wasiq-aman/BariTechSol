const express = require('express');
const axios = require('axios');
const bodyParser = require('body-parser');
const app = express();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

const url = "https://dummy.restapiexample.com/api/v1";

async function getEmployees(employeeId) {
    if (employeeId) {
        let employeeData = await axios.get(`${url}/employee/${employeeId}`);
        return employeeData.data.data;
    } else {
        let existingData = await axios.get(`${url}/employees`);
        return existingData.data.data;
    }
}

app.get('/data', async (req, res) => {
    const employeeId = req.query.id;
    try {
        let employeesData = await getEmployees(employeeId);
        res.json(employeesData);
    } catch (error) {
        res.status(500).json({ error: error.message });
    } 
});

app.post('/create', async (req, res) => {
    try {
          let newData = req.body;
          if (!Array.isArray(newData)) {
                 newData = [newData]; 
                    }
          if (newData.length === 0) {
              return res.status(400).json({ error: 'Invalid or missing request body' });
                    }
        let employees = await getEmployees();
        newData.forEach((obj) => {
            employees.push({
                    id: obj?.id || "",
                    employee_name: obj?.employee_name || "",
                    employee_salary: obj?.employee_salary || "",
                    employee_age: obj?.employee_age || "",
                    profile_image: obj?.profile_image || "",
                })   
        });
        res.json(employees);
    } catch (error) {
        res.status(500).json({
            errorStatus: error.response.status,
            error: error.message
        });
    }});

app.post('/update', async (req, res) => {
    try {
        let updatedEmployeesData = req.body;
        if (!Array.isArray(updatedEmployeesData)) {
            updatedEmployeesData = [updatedEmployeesData];
        }
        if (updatedEmployeesData.length === 0) {
            return res.status(400).json({ error: 'Invalid or missing request body' });
        }
         let employees = await getEmployees();
        updatedEmployeesData.forEach((updatedEmployeeData) => {
            let employee = employees.find(emp => emp.id === updatedEmployeeData.id);
            if (employee) {
                employee.employee_name = updatedEmployeeData.employee_name ?? "";
                employee.employee_salary = updatedEmployeeData.employee_salary ?? "";
                employee.employee_age = updatedEmployeeData.employee_age ?? "";
                employee.profile_image = updatedEmployeeData.profile_image ?? "";
            } else {
              res.status(400).json({ error: 'Id is not valid' });
            }
        });
        res.json(employees);
    } catch (error) {
        res.status(500).json({
            errorStatus:  error.response.status,
            error: error.message
        });
    }
});
       
app.delete('/delete', async (req, res) => {
    try {
        let ids = req.query.id;
        let arr = !ids ? '' : ids.split(',').map(Number).filter(id => !isNaN(id));
        if (  arr.length === 0 ) {
            return res.status(400).json({ error: 'Employee ID is missing or invalid in the query parameter' });
        }
        let employees = await getEmployees();
        let employeeFound =false;
        for (let id of arr) {
            const empToDelete = id;
            let index = employees.find(emp => emp.id === empToDelete);
            if (index) {
                const indexToRemove = employees.indexOf(index);
                employees.splice(indexToRemove, 1);
                employeeFound = true;
            }}
        if (employeeFound) {
            res.json(employees);
        } else {
            return res.status(404).json({ error: 'One or more employees not found' });
        }
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

module.exports = app;





