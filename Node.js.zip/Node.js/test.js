const express = require('express');
const router = express.Router();
const bodyParser = require('body-parser');
test.use(bodyParser.urlencoded({ extended: true }));
test.use(bodyParser.json());
router.post('/name', (req, res) => {
    const name = req.body?.var; 
    if (!name) { 
        return res.send("Error: Input value is null or undefined.");
    }

    let reversed = '', word = '';
    const arr = name.split(' ');
    for (let i = 0; i < arr.length; i++) {
        if (arr[i] !== '') {
            
            for (let j = 0; j < arr[i].length; j++) {
                word = arr[i][j] + word;
            }
            reversed = reversed + word + ' ';
        }
    }
    res.send(`Reversed String: ${reversed}`);
});

module.exports = router;

