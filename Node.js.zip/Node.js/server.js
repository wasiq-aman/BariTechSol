const express = require('express');
const test = require('./test');

const server = express();
const port = 3000;

server.use('/', test);

server.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`);
});
