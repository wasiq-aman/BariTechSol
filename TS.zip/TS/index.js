"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const axios_1 = __importDefault(require("axios"));
const app = (0, express_1.default)();
app.use(express_1.default.urlencoded({ extended: true }));
app.use(express_1.default.json());
const url = "htt ps://dummy.restapiexample.com/api/v1";
let EmployeeArray = [];
// interface EmployeeArray extends Array<Employee>{}
const getEmployees = (employeeId) => __awaiter(void 0, void 0, void 0, function* () {
    if (employeeId) {
        let employeeData = yield axios_1.default.get(`${url}/employee/${employeeId}`);
        return employeeData.data;
    }
    else {
        let existingData = yield axios_1.default.get(`${url}/employees`);
        return existingData.data;
    }
});
app.get('/data', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const employeeId = req.query.id;
    try {
        const employeesData = yield getEmployees(employeeId);
        res.json(employeesData);
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
}));
// app.post('/create', async (req, res) => {
//     try {
//         let newData: Employee | Employee[] = req.body;
//         if (!Array.isArray(newData)) {
//             newData = [newData];
//         }
//         if (newData.length === 0) {
//             return res.status(400).json({ error: 'Invalid or missing request body' });
//         }
//         let employees = await getEmployees() as Employee[];
//         newData.forEach((obj: Employee) => {
//             employees.push({
//                 id: obj?.id || "",
//                 employee_name: obj?.employee_name || "",
//                 employee_salary: obj?.employee_salary || "",
//                 employee_age: obj?.employee_age || "",
//                 profile_image: obj?.profile_image || "",
//             })   
//         });
//         res.json(employees);
//     } catch (error: any) {
//         res.status(500).json({ error: error.message });
//     }
// });
// app.post('/update', async (req, res) => {
//     try {
//         let updatedEmployeesData: Employee | Employee[] = req.body;
//         if (!Array.isArray(updatedEmployeesData)) {
//             updatedEmployeesData = [updatedEmployeesData];
//         }
//         if (updatedEmployeesData.length === 0) {
//             return res.status(400).json({ error: 'Invalid or missing request body' });
//         }
//         let employees = await getEmployees() as Employee[];
//         updatedEmployeesData.forEach((updatedEmployeeData: Employee) => {
//             let employee : Employee | undefined = employees?.find(emp => emp.id === updatedEmployeeData.id);
//             if (employee) {
//                 employee.employee_name = updatedEmployeeData.employee_name ?? "";
//                 employee.employee_salary = updatedEmployeeData.employee_salary ?? "";
//                 employee.employee_age = updatedEmployeeData.employee_age ?? "";
//                 employee.profile_image = updatedEmployeeData.profile_image ?? "";
//            } else {
//                 res.status(400).json({ error: 'Id is not valid' });
//             }
//         });
//         res.json(employees);
//     } catch (error: any) {
//         res.status(500).json({ error: error.message });
//     }
// });
// app.delete('/delete', async (req, res) => {
//     try {
//         let ids: string | undefined = req.query.id as string | undefined;
//         let arr: number[] = !ids ? [] : ids.split(',').map(Number).filter(id => !isNaN(id));
//         if (arr.length === 0) {
//             return res.status(400).json({ error: 'Employee ID is missing or invalid in the query parameter' });
//         }
//         let employees = await getEmployees() as Employee[];
//         let employeeFound: boolean = false;
//         for (let id of arr) {
//             const empToDelete : number = id;
//             let index : Employee | undefined = employees.find(emp => emp.id === empToDelete);
//             if (index) {
//                 const indexToRemove = employees?.indexOf(index);
//                 employees?.splice(indexToRemove, 1);
//                 employeeFound = true;
//             }}
//         if (employeeFound) {
//             res.json({});
//         } else {
//             return res.status(404).json({ error: 'One or more employees not found' });
//         }
//     } catch (error: any) {
//         res.status(500).json({ error: error.message });
//     }
// });
exports.default = app;
