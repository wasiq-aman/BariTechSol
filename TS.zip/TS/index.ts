import express, { Request, Response } from 'express';
import axios from 'axios';
const app = express();
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
const url: string = "htt ps://dummy.restapiexample.com/api/v1";

interface Employee {
    id: number | string;
    employee_name: string;
    employee_salary: number | string;
    employee_age: number | string;
    profile_image: string;
}

let EmployeeArray: Employee[] = [];

// interface EmployeeArray extends Array<Employee>{}


const getEmployees = async (employeeId?: string) => {
    if (employeeId) {
        let employeeData : {data:Employee}  = await axios.get(`${url}/employee/${employeeId}`);
        return employeeData.data;
    } else {
        let existingData :{data:Employee[]}  = await axios.get(`${url}/employees`);
        return existingData.data;
    
    }
};
app.get('/data', async (req, res) => {
    const employeeId: string | undefined = req.query.id as string | undefined;
    try {
        const employeesData: Employee | Employee[] = await getEmployees(employeeId);
        res.json(employeesData);
    } catch (error: any) {
        res.status(500).json({ error: error.message });
    }
});

// app.post('/create', async (req, res) => {
//     try {
//         let newData: Employee | Employee[] = req.body;
//         if (!Array.isArray(newData)) {
//             newData = [newData];
//         }
//         if (newData.length === 0) {
//             return res.status(400).json({ error: 'Invalid or missing request body' });
//         }
//         let employees = await getEmployees() as Employee[];
//         newData.forEach((obj: Employee) => {
//             employees.push({
//                 id: obj?.id || "",
//                 employee_name: obj?.employee_name || "",
//                 employee_salary: obj?.employee_salary || "",
//                 employee_age: obj?.employee_age || "",
//                 profile_image: obj?.profile_image || "",
//             })   
//         });
//         res.json(employees);
//     } catch (error: any) {
//         res.status(500).json({ error: error.message });
//     }
// });

// app.post('/update', async (req, res) => {
//     try {
//         let updatedEmployeesData: Employee | Employee[] = req.body;
//         if (!Array.isArray(updatedEmployeesData)) {
//             updatedEmployeesData = [updatedEmployeesData];
//         }
//         if (updatedEmployeesData.length === 0) {
//             return res.status(400).json({ error: 'Invalid or missing request body' });
//         }
//         let employees = await getEmployees() as Employee[];
//         updatedEmployeesData.forEach((updatedEmployeeData: Employee) => {
        
//             let employee : Employee | undefined = employees?.find(emp => emp.id === updatedEmployeeData.id);
//             if (employee) {
//                 employee.employee_name = updatedEmployeeData.employee_name ?? "";
//                 employee.employee_salary = updatedEmployeeData.employee_salary ?? "";
//                 employee.employee_age = updatedEmployeeData.employee_age ?? "";
//                 employee.profile_image = updatedEmployeeData.profile_image ?? "";
//            } else {
//                 res.status(400).json({ error: 'Id is not valid' });
//             }
//         });
//         res.json(employees);
//     } catch (error: any) {
//         res.status(500).json({ error: error.message });
//     }
// });

// app.delete('/delete', async (req, res) => {
//     try {
//         let ids: string | undefined = req.query.id as string | undefined;
//         let arr: number[] = !ids ? [] : ids.split(',').map(Number).filter(id => !isNaN(id));
//         if (arr.length === 0) {
//             return res.status(400).json({ error: 'Employee ID is missing or invalid in the query parameter' });
//         }
//         let employees = await getEmployees() as Employee[];
//         let employeeFound: boolean = false;
//         for (let id of arr) {
//             const empToDelete : number = id;
//             let index : Employee | undefined = employees.find(emp => emp.id === empToDelete);
//             if (index) {
//                 const indexToRemove = employees?.indexOf(index);
//                 employees?.splice(indexToRemove, 1);
//                 employeeFound = true;
//             }}
//         if (employeeFound) {
//             res.json({});
//         } else {
//             return res.status(404).json({ error: 'One or more employees not found' });
//         }
//     } catch (error: any) {
//         res.status(500).json({ error: error.message });
//     }
// });

export default app;


