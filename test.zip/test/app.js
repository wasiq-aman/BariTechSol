const express = require('express');
var bodyParser = require('body-parser')
const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
    app.post('/name', (req, res) => { 
        const name = req.body.var; 
        var reversed = '', word = '';
        var arr = name.split(' ');
      console.log(arr)
        for (var i = 0; i < arr.length; i++) {
            if (arr[i] !==  '') {
                for (var j = 0; j < arr[i].length; j++) {
                    word = arr[i][j]+ word;      
                 }
                    reversed = reversed + word + ' ';
                    word = '';
        }}      
    if(reversed.startsWith(' ')){
        reserved = reversed.replace(' ','');} 
       if(reversed.startsWith("' ")){
               reserved = reversed.replace("' ","'")}
             if(reversed.endsWith(' ')){
                   reserved = reversed.replace(' ','')}
                    if(reversed.endsWith(" '")){
                          reserved = reversed.replace(" '","'")}
    // reversed = reversed.trim();
    res.send(`Reversed String: ${reversed}`);      
    });
app.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`);
});


