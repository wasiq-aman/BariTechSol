app.post('/getmongo', function(req, res) {
    filters = req.body.filters;
    db.collection('app.js').find(filters).toArray(function(err, docs) {
        if (err) {
            console.log(err);
            return res.send(500, 'something went wrong');
        } else {
            res.send({"ISM": docs});

            // If you want to return JSON
            // res.json({"ISM": docs});
        }
    });
});